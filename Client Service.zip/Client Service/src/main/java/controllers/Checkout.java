package controllers;

import Model.Product;
import amqpConfig.AmqpConfiguration;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/checkout")
public class Checkout extends HttpServlet {

   public  AnnotationConfigApplicationContext context;
   public CachingConnectionFactory connectionFactory;
    public void init() throws ServletException {
         context = new AnnotationConfigApplicationContext(AmqpConfiguration.class);



    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        HttpSession session = req.getSession();
        List<Product> products = (List<Product>) session.getAttribute("cartProducts");
        int totalPrice = 0;

        for (Product pr : products) {

            totalPrice = totalPrice + Integer.parseInt(pr.getPrice());
        }


         session.setAttribute("totalPrice", totalPrice);
//        System.out.println("cart get entered");
//        System.out.println(totalPrice);

        // total  price
        resp.setContentType("text/html");
       // PrintWriter out = response.getWriter();
        // String to=request.getParameter("to");
        String to = "tekket08@gmail.com";
      //  String subject=request.getParameter("subject");

        String subject = "The Blue Shop!Thank you very much,this is a confirmation for your payment";
      //  String msg=request.getParameter("msg");
        StringBuilder sb = new StringBuilder();
        for (Product p : products)
        {
            sb.append(p.toString());
            sb.append("\t");
        }
        String msg = sb.toString() + "\n" + "total Price" +"\t" +
        totalPrice + "\n"+ "Thank you very much!!!";
        Mailer.send(to, subject, msg);

        // added for messaging
////
        RabbitTemplate orderStoreTemplate =  context.getBean("orderStoreTemplate",RabbitTemplate.class);
           orderStoreTemplate.convertAndSend(msg);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

          // sending message to head quarter
        RabbitTemplate orderOnlineTemplate =  context.getBean("orderOnlineTemplate",RabbitTemplate.class);
         orderOnlineTemplate.convertAndSend(msg);

            // sending message to Ware house
        RequestDispatcher dispatcher = req.getRequestDispatcher("checkout.jsp");
       dispatcher.forward(req,resp);
//
//    }
    }

}
