package amqpService;


import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.ArrayList;
import java.util.List;

//public class OrderStoreServiceImpl implements OrderService {
//    public void publish(RabbitTemplate rabbitTemplate) {
////
////    	// Dummy up an order
////    	// First need a Product:
////    	Product product = new Product("Kazoo", "a Hummer", 2);
////    	// Order 2 of them
////    	OrderItem orderItem = new OrderItem(2, product);
////    	// Make a list of the orderItems [ only 1]
////    	List<OrderItem> orderItems = new ArrayList<OrderItem>();
////        orderItems.add(orderItem);
////
////        OrderPayment orderPayment = new OrderPayment();
////        // Create order...
////        Order order = new Order("123",orderItems,orderPayment);
////        rabbitTemplate.convertAndSend(order);
////
////    	// Dummy up a  SECOND order - simply change the product name
////        order.getItems().get(0).getProduct().setName("Water Balloon");
////        rabbitTemplate.convertAndSend(order);
////
//
//    }
//}
