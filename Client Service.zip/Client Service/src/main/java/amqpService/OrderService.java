package amqpService;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

public interface OrderService {
    public void publish(RabbitTemplate rabbitTemplate,String message);
}
