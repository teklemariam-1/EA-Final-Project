# OY-inventory-manager
An inventory management solution that aim to solve merchant headache on managing his inventory and reporting across different locations
