package edu.mum.cs.inventorymanager.controller.ui;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.mum.cs.inventorymanager.config.AmqpDirectOnlineConsumerMainJava;

@Controller
public class HomepageController {

	@RequestMapping(value={"/home","/","/index",""}, method=RequestMethod.GET)
	public String homepage() {
		System.out.print("message place");
		// start messaging
		AmqpDirectOnlineConsumerMainJava.startMessaging();
		return "homepage/index";
	}

}