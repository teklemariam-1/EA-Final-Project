package edu.mum.cs.inventorymanager.model;



public class Report {

}
