package edu.mum.cs.inventorymanager.listener;

import edu.mum.cs.inventorymanager.messageModel.Order;

public class DirectOnlineListener {
	public void listen1(Order order) {
		
		String name = order.getItems().get(0).getProduct().getName();
		System.out.println("---------- AMQPClient Order for Product on OrderOnlineQueue: " + name);
	}

}
