package com.infotech.batch.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;

import com.infotech.batch.model.SalesPersons;

public class PersonItemProcessor implements ItemProcessor<SalesPersons, SalesPersons> {

    private static final Logger log = LoggerFactory.getLogger(PersonItemProcessor.class);

    @Override
    public SalesPersons process(final SalesPersons salesPersons) throws Exception {
        final String firstName = salesPersons.getFirstName().toUpperCase();
        final String lastName = salesPersons.getLastName().toUpperCase();

        final SalesPersons transformedPerson = new SalesPersons(firstName, lastName,salesPersons.getEmail(),salesPersons.getAge());

        log.info("Converting (" + salesPersons + ") into (" + transformedPerson + ")");

        return transformedPerson;
    }

}