package com.infotech.batch.config;

import java.util.concurrent.CountDownLatch;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infotech.batch.service.EmailService;

import edu.mum.cs.inventorymanager.model.entity.Buyer;

@Component
public class RabbitListener {

    private CountDownLatch countDownLatch = new CountDownLatch(1);
    
    @Autowired
    private EmailService emailService;
   
    public void receiveMessage(Buyer buyer) throws MessagingException {
    	System.out.println("this is message reciever....");
    	System.out.println(buyer);
		String from = "livanhaddishmwa@gmail.com";
		String to = buyer.getEmail();
		String subject = "Invoice for the order";
		String body = " Dear "+buyer.getFirstName()+" "+buyer.getLastName() +" your order is confirmed ";
		
		emailService.sendMail(from, to, subject, body);
    	
        System.out.println("message = [" + buyer + "]");
        countDownLatch.countDown();
    }

    public CountDownLatch getCountDownLatch() {
        return countDownLatch;
    }
}
